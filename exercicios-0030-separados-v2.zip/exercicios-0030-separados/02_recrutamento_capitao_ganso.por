programa {
  funcao inicio() {
    logico sabe_nadar, tem_recomendacao
    inteiro idade

    escreva("Sabe nadar? (verdadeiro/falso): ")
    leia(sabe_nadar)
    escreva("Idade: ")
    leia(idade)
    escreva("Tem recomendacao? (verdadeiro/falso): ")
    leia(tem_recomendacao)

    se (sabe_nadar e idade > 16) {
      escreva("Aprovado para o navio!")
    } senao se (nao sabe_nadar e tem_recomendacao e idade >= 14) {
      escreva("Aprovado sob recomendação. Monitorar nas primeiras viagens.")
    } senao {
      escreva("Reprovado. Volte quando estiver mais preparado para o mar.")
    }
  }
}
