programa {
  funcao inicio() {
    inteiro criancas
    real vento

    escreva("Tem crianca pequena perto? (qtde): ")
    leia(criancas)
    escreva("Velocidade do vento: ")
    leia(vento)

    se (criancas == 0 e vento >= 0.5) {
      escreva("Fumaça liberada. Que comecem os mistérios!")
    } senao {
      escreva("Fumaça bloqueada. Aguardar condições ideais.")
    }
  }
}
