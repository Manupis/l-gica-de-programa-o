programa {
  funcao inicio() {
    logico manutencao, emergencia

    escreva("Em manutencao? (verdadeiro/falso): ")
    leia(manutencao)
    escreva("Emergencia ativa? (verdadeiro/falso): ")
    leia(emergencia)

    se (nao manutencao e nao emergencia) {
      escreva("Transporte liberado para uso.")
    } senao {
      escreva("Transporte indisponível por motivo de segurança.")
    }
  }
}
