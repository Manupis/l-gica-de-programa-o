programa {
  funcao inicio() {
    inteiro visitantes, hora

    escreva("Quantos visitantes na area? ")
    leia(visitantes)
    escreva("Que horas sao? (0 a 23): ")
    leia(hora)

    se (visitantes == 0 e (hora < 8 ou hora > 18)) {
      escreva("Liberação autorizada. Abrindo jaula.")
    } senao {
      escreva("Liberação negada. Área em uso ou fora do horário permitido.")
    }
  }
}
