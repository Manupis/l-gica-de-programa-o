programa {
  funcao inicio() {
    inteiro marujos
    real comida, comida_certa

    escreva("Quantos marujos tem? ")
    leia(marujos)
    escreva("Quantos kg de comida tem? ")
    leia(comida)

    comida_certa = marujos * 1.5

    se (marujos >= 10 e comida >= comida_certa) {
      escreva("Provisões suficientes. Rumo ao horizonte!")
    } senao {
      escreva("Algo está errado. Posseidom não quer ninguém no mar hoje.")
    }

    // bonus do 1
    inteiro dias
    real rum
    escreva("\n--- bonus ---\n")
    escreva("Vai ficar quantos dias? ")
    leia(dias)
    escreva("Quantos litros de rum tem? ")
    leia(rum)

    comida_certa = marujos * 1.5 * dias

    se (marujos < 10) {
      escreva("Faltou marujo: ", 10 - marujos, "\n")
    }
    se (comida < comida_certa) {
      escreva("Faltou comida (kg): ", comida_certa - comida, "\n")
    }
    se (dias > 1 e rum < 2.0) {
      escreva("Faltou rum pra viagem longa\n")
    }

    se (comida > comida_certa e marujos > 0) {
      real sobra = comida - comida_certa
      real dias_a_mais = (sobra/(marujos * 1.5))
      escreva("Da pra ficar mais ", dias_a_mais, " dia(s) com essa comida\n")
    }
  }
}
