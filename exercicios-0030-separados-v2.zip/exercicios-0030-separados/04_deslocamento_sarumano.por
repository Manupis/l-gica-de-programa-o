programa {
  funcao inicio() {
    logico gripado
    inteiro tempo

    escreva("Ta gripado? (verdadeiro/falso): ")
    leia(gripado)
    escreva("Tempo de viagem em minutos: ")
    leia(tempo)

    se (nao gripado e tempo < 45) {
      escreva("Viagem autorizada. Rumo ao show!")
    } senao {
      escreva("Deslocamento inviável. Melhor recusar este evento.")
    }
  }
}
