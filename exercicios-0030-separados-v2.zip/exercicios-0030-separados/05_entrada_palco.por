programa {
  funcao inicio() {
    logico som_ok, figurino_ok

    escreva("Som ta funcionando? (verdadeiro/falso): ")
    leia(som_ok)
    escreva("Figurino ta completo? (verdadeiro/falso): ")
    leia(figurino_ok)

    se (som_ok e figurino_ok) {
      escreva("Palco liberado para Sarumano! Luzes, câmera, ilusão!")
    } senao se (nao som_ok e figurino_ok) {
      escreva("Sem som. Realizar apresentação alternativa no salão.")
    } senao se (som_ok e nao figurino_ok) {
      escreva("Faltando parte do figurino. Te vira no improviso!")
    } senao {
      escreva("Apresentação cancelada. Hora da mágica de desaparecer…")
    }
  }
}
