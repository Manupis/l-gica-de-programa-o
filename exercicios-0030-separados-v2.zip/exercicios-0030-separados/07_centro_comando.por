programa {
  funcao inicio() {
    logico cracha, digital

    escreva("Cracha valido? (verdadeiro/falso): ")
    leia(cracha)
    escreva("Digital reconhecida? (verdadeiro/falso): ")
    leia(digital)

    // basico
    se (cracha e digital) {
      escreva("Acesso permitido\n")
    } senao {
      escreva("Acesso negado\n")
    }

    // bonus
    escreva("--- com mensagem detalhada ---\n")
    se (cracha e digital) {
      escreva("Acesso liberado ao Centro de Comando")
    } senao se (nao cracha e digital) {
      escreva("Crachá inválido. Dirija-se à recepção")
    } senao se (cracha e nao digital) {
      escreva("Falha na digital. Tente novamente ou chame o suporte")
    } senao {
      escreva("Acesso negado. Verifique sua identificação.")
    }
  }
}
